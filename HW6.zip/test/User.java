package com.example.test;

public class User{
    String SerialNumber;
    String CompanyName;
    String EmployeeMarkme;
    String Description;
    String Leave;
}