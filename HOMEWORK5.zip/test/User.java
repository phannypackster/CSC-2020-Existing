package com.example.test;

public class User{
    String Name;
    String Address;
    String Phone;
}